import { useState } from 'react'
import './App.css'

function Header() {
  const [count, setCount] = useState(0)

  return (
    <>
      <p>Header</p>
    </>
  )
}

export default App
